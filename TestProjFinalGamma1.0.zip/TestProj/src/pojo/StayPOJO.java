package pojo;

public class StayPOJO {

	int c_hotel_id;
	String c_hotel_name;
	String c_hotel_desc;
	double c_hotel_price;
	int c_no_of_nights;
	
	public int getC_hotel_id() {
		return c_hotel_id;
	}
	public void setC_hotel_id(int c_hotel_id) {
		this.c_hotel_id = c_hotel_id;
		System.out.println(c_hotel_id);
	}
	public String getC_hotel_name() {
		return c_hotel_name;
	}
	public void setC_hotel_name(String c_hotel_name) {
		this.c_hotel_name = c_hotel_name;
	}
	public String getC_hotel_desc() {
		return c_hotel_desc;
	}
	public void setC_hotel_desc(String c_hotel_desc) {
		this.c_hotel_desc = c_hotel_desc;
	}
	public double getC_hotel_price() {
		return c_hotel_price;
	}
	public void setC_hotel_price(double c_hotel_price) {
		this.c_hotel_price = c_hotel_price;
	}
	public int getC_no_of_nights() {
		return c_no_of_nights;
	}
	public void setC_no_of_nights(int c_no_of_nights) {
		this.c_no_of_nights = c_no_of_nights;
	}
	
}

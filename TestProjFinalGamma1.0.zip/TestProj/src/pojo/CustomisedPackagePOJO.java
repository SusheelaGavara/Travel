package pojo;

public class CustomisedPackagePOJO {
	int cId;
	int user_id;
	int cFlightId;
	int cHotelId;
	String cDeptDate;
	int cNoOfNights;
	double cHotelCost;
	double cTotalCost;
	String cBookingDate;
	
	public int getcId() {
		return cId;
	}
	public void setcId(int cId) {
		this.cId = cId;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public int getcFlightId() {
		return cFlightId;
	}
	public void setcFlightId(int cFlightId) {
		this.cFlightId = cFlightId;
	}
	public int getcHotelId() {
		return cHotelId;
	}
	public void setcHotelId(int cHotelId) {
		this.cHotelId = cHotelId;
	}
	public String getcDeptDate() {
		return cDeptDate;
	}
	public void setcDeptDate(String cDeptDate) {
		this.cDeptDate = cDeptDate;
	}
	public int getcNoOfNights() {
		return cNoOfNights;
	}
	public void setcNoOfNights(int cNoOfNights) {
		this.cNoOfNights = cNoOfNights;
	}
	public double getcHotelCost() {
		return cHotelCost;
	}
	public void setcHotelCost(double cHotelCost) {
		this.cHotelCost = cHotelCost;
	}
	public double getcTotalCost() {
		return cTotalCost;
	}
	public void setcTotalCost(double cTotalCost) {
		this.cTotalCost = cTotalCost;
	}
	public String getcBookingDate() {
		return cBookingDate;
	}
	public void setcBookingDate(String cBookingDate) {
		this.cBookingDate = cBookingDate;
	}

	
	
}

package pojo;

public class UserPOJO {
	
		private int user_id;
		private String user_login_id;
		private String user_password;
		private String user_fname;
		private String user_lname;
		private String user_type;
		private String user_bdate;
		private String user_gender;
		private String user_emailid;
		private Long user_contact;
		private String user_address;
		private String user_city;
		private int user_zipcode;
		private String user_country;
		
		
		public int getUser_id() {
			return user_id;
		}
		public void setUser_id(int user_id) {
			this.user_id = user_id;
		}
		public String getUser_login_id() {
			return user_login_id;
		}
		public void setUser_login_id(String user_login_id) {
			this.user_login_id = user_login_id;
		}
		public String getUser_password() {
			return user_password;
		}
		public void setUser_password(String user_password) {
			this.user_password = user_password;
		}
		public String getUser_fname() {
			return user_fname;
		}
		public void setUser_fname(String user_fname) {
			this.user_fname = user_fname;
		}
		public String getUser_lname() {
			return user_lname;
		}
		public void setUser_lname(String user_lname) {
			this.user_lname = user_lname;
		}
		public String getUser_type() {
			return user_type;
		}
		public void setUser_type(String user_type) {
			this.user_type = user_type;
		}
		public String getUser_bdate() {
			return user_bdate;
		}
		public void setUser_bdate(String user_bdate) {
			this.user_bdate = user_bdate;
		}
		public String getUser_gender() {
			return user_gender;
		}
		public void setUser_gender(String user_gender) {
			this.user_gender = user_gender;
		}
		public String getUser_emailid() {
			return user_emailid;
		}
		public void setUser_emailid(String user_emailid) {
			this.user_emailid = user_emailid;
		}
		public Long getUser_contact() {
			return user_contact;
		}
		public void setUser_contact(Long user_contact) {
			this.user_contact = user_contact;
		}
		public String getUser_address() {
			return user_address;
		}
		public void setUser_address(String user_address) {
			this.user_address = user_address;
		}
		public String getUser_city() {
			return user_city;
		}
		public void setUser_city(String user_city) {
			this.user_city = user_city;
		}
		public int getUser_zipcode() {
			return user_zipcode;
		}
		public void setUser_zipcode(int user_zipcode) {
			this.user_zipcode = user_zipcode;
		}
		public String getUser_country() {
			return user_country;
		}
		public void setUser_country(String user_country) {
			this.user_country = user_country;
		}
		
		

}

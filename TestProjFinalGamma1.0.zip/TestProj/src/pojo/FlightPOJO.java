package pojo;

public class FlightPOJO {
	String c_dept_city;
	String c_dest_city;
	int c_flight_id;
	String c_dept_date;
	double c_flight_cost;
	
	public String getC_dept_city() {
		return c_dept_city;
	}
	public void setC_dept_city(String c_dept_city) {
		this.c_dept_city = c_dept_city;
	}
	public String getC_dest_city() {
		return c_dest_city;
	}
	public void setC_dest_city(String c_dest_city) {
		this.c_dest_city = c_dest_city;
	}
	public int getC_flight_id() {
		return c_flight_id;
	}
	public void setC_flight_id(int c_flight_id) {
		this.c_flight_id = c_flight_id;
	}
	public String getC_dept_date() {
		return c_dept_date;
	}
	public void setC_dept_date(String c_dept_date) {
		this.c_dept_date = c_dept_date;
	}
	public double getC_flight_cost() {
		return c_flight_cost;
	}
	public void setC_flight_cost(double c_flight_cost) {
		this.c_flight_cost = c_flight_cost;
	}
	
}
